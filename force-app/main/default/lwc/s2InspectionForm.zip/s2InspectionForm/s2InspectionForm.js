import { LightningElement } from 'lwc';

export default class S2InspectionForm extends LightningElement {}